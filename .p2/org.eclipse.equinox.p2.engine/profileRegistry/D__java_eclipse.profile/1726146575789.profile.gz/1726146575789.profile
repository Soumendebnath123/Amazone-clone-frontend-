<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='D__java_eclipse' timestamp='1726146575789'>
  <properties size='7'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Users\Soumen Debnath\.p2\pool'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32'/>
    <property name='org.eclipse.oomph.p2.profile.type' value='Installation'/>
    <property name='org.eclipse.oomph.p2.profile.shared.pool' value='true'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='D:\java\eclipse'/>
  </properties>
</profile>
